 # 👋 Introduction to Postman course

Hello and welcome to this free course on writing API tests with Postman. 

[![Watch the video on freeCodeCamp](https://img.youtube.com/vi/VywxIQ2ZXw4/maxresdefault.jpg)](https://www.youtube.com/watch?v=VywxIQ2ZXw4)

## Important links

* [📝 Course notes](./course-notes.md)
* [📚 Simple Books API documentation](./simple-books-api.md)
* [💬 Join the Discord Group for help](https://discord.gg/EEEct8sgYM)

## Get in touch

* [📺 Subscribe to my YouTube channel](https://www.youtube.com/channel/UCUUl_HXJjU--iYjUkIgEcTw)
* [🐦 Twitter](https://twitter.com/vdespa)
* [🏢 LinkedIn](https://www.linkedin.com/in/vdespa/)
* [🎓 My other Courses](https://vdespa.com/courses)

## Learn even more

* [💻 Postman Complete course for API testing  - with FreeCodeCamp discount](https://www.udemy.com/course/postman-the-complete-guide/?couponCode=FREECODECAMP_2021) 
